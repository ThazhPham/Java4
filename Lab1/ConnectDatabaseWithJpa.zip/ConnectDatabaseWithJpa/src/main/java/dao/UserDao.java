package dao;

import java.util.List;

import entity.User;

public interface UserDao {
	
	// Tạo User
	public void create(User item);
    // Các hàm khác...
	public List<User> findAll();	
	public User findById(String id);
	public void update(User item);
	public void deleteById(String id);
	public List<User> findEmail();
	public List<User> findPage(int pageNumber, int pageSize);
}