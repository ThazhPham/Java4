package dao;

import java.util.List;

import entity.User;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import utils.XJpa;

public class UserDaoImpl implements UserDao {

	@Override
	public void create(User item) {
		EntityManager em = XJpa.getEntityManager();
		User user = new User("U02","113","trong@fpt.edu.vn","Trọng",false);
		try {
			em.getTransaction().begin();
			em.persist(user);
			em.getTransaction().commit();
			System.out.println("Đã lưu User thành công");
		} catch (Exception e) {
			em.getTransaction().rollback();
		}
	}
	
	@Override
	public List<User> findAll() {
		EntityManager em = XJpa.getEntityManager();
		String jpql = "SELECT o FROM User o";
		TypedQuery<User> query = em.createQuery(jpql, User.class);
		List<User> list = query.getResultList();
//		list.forEach(user -> {
//			String id = user.getId();
//			String fullname = user.getFullname();
//			boolean admin = user.getAdmin();
//			System.out.println(id + "---" + fullname + ":" + admin);
//		});
		return list;
	}
	
	@Override
	public List<User> findPage(int pageNumber, int pageSize) {
		EntityManager em = XJpa.getEntityManager();
		String jpql = "SELECT o FROM User o ORDER BY o.id";
		TypedQuery<User> query = em.createQuery(jpql, User.class);
		query.setFirstResult(pageNumber * pageSize);
        query.setMaxResults(pageSize);
        List<User> list = query.getResultList();
        System.out.println("Danh sách User ở Trang " + (pageNumber + 1) + " Kích thước: " + pageSize); //Pagenumber ở trang 2
        System.out.println("Bắt đầu từ vị trí: " + pageNumber * pageSize);
        list.forEach(user -> {
        	String id = user.getId();
        	String fullname = user.getFullname();
        	String email = user.getEmail();
        	System.out.println(id + "---" + fullname + ":" + email);
        });
        return list;
	}
	
	@Override
	public List<User> findEmail() {
		EntityManager em = XJpa.getEntityManager();
		String jpql = "SELECT o FROM User o WHERE o.email LIKE :search AND o.admin = :role";
		TypedQuery<User> query = em.createQuery(jpql, User.class);
		query.setParameter("search", "%@fpt.edu.vn");
		query.setParameter("role", false);
		List<User> list = query.getResultList();
		list.forEach(user -> {
			String email = user.getEmail();
			String fullname = user.getFullname();
			System.out.println("Họ tên: " + fullname + " - Email: " + email);
		});
		return list;
	}
	
	@Override
	public void update(User item) {
		EntityManager em = XJpa.getEntityManager();
		User user = em.find(User.class, "U01");
		user.setFullname("Lê Hữu Trọng");
		user.setEmail("lhtrong@fpt.edu.vn");
		try {
			em.getTransaction().begin();
			em.merge(user);
			em.getTransaction().commit();
			System.out.println("Cập nhật thành công");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void deleteById(String id) {
		EntityManager em = XJpa.getEntityManager();
		User user = em.find(User.class, "U02");
		try {
			em.getTransaction().begin();
			em.remove(user);
			em.getTransaction().commit();
			System.out.println("Xóa thành công");
		} catch (Exception e) {
			em.getTransaction().rollback();
		}
	}
	
	@Override
	public User findById(String id) {
		EntityManager em = XJpa.getEntityManager();
		User user = em.find(User.class, "user_demo_11");
		String fullname = user.getFullname();
		boolean admin = user.getAdmin();
		System.out.println(id + "---" +fullname + ":" +admin);
		return user;
	}

}
