package dao;

import entity.User;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class Demo {
	public static void main(String[] args) {
		UserDao udao = new UserDaoImpl();
		//create
//		udao.create(null);	
		
		
		//FindById
//		udao.findById("user_demo_11");
		
		//update
//		udao.update(null);
		
		//delete
//		udao.deleteById(null);
		
		//findall
//		udao.findAll();
		
		//find email
//		udao.findEmail();
		
		//page
		udao.findPage(0, 5);
		
	}
}
