-- Xóa database nếu đã tồn tại (tránh lỗi trùng)
IF EXISTS (SELECT name FROM sys.databases WHERE name = N'students')
BEGIN
    ALTER DATABASE students SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE students;
END
GO

-- Tạo mới database
CREATE DATABASE students;
GO

USE students;
GO

-- Tạo bảng Users
IF OBJECT_ID('dbo.Users', 'U') IS NOT NULL
    DROP TABLE dbo.Users;
GO

CREATE TABLE dbo.Users (
    ID NVARCHAR(20) NOT NULL PRIMARY KEY,
    [Password] NVARCHAR(50) NOT NULL,
    Fullname NVARCHAR(50) NOT NULL,
    Email NVARCHAR(50) NOT NULL,
    [Admin] BIT NOT NULL
);
GO

-- Chèn dữ liệu mẫu
INSERT INTO dbo.Users (ID, [Password], Fullname, Email, [Admin])
VALUES 
('admin01', 'e10adc3949ba59abbe56e057f20f883e', N'Nguyễn Văn A', 'nguyenvana@university.edu.vn', 1),
('user101', 'c20ad4d76fe97759aa27a0c99bff6710', N'Trần Thị B', 'tranthib@university.edu.vn', 0),
('user102', '5af28f322315a676c12513a9de00d024', N'Lê Văn C', 'levanc@university.edu.vn', 0),
('manager05', 'fcea920f7412b5da7be0cf42b8c93759', N'Phạm Thị D', 'phamd@university.edu.vn', 1),
('user103', '751d3b036502209772c3d5e317d7f7a7', N'Hoàng Đình E', 'hoangdinhe@university.edu.vn', 0);
GO

-- Kiểm tra dữ liệu
SELECT * FROM dbo.Users;
GO
